XBMC movie information scraper from www.cinemarx.ro

Use with XBMC installed (www.xbmc.org). For bugreports and feature requests, please fill in an Issue.