[![Codacy Badge](https://api.codacy.com/project/badge/Grade/e5d8dc168cf940a385d1a47837fe7596)](https://www.codacy.com/app/92enen/screensaver.atv4?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=enen92/screensaver.atv4&amp;utm_campaign=Badge_Grade)

# screensaver.atv4

## Apple Aerial screensavers for Kodi

This addon lets you add the apple tv 4 screensavers to Kodi Entertainment Center

## Supported versions

Aerial is available for Kodi Matrix and above. It can be installed via the Kodi official repository.

# Screenshots

![Screenshot1](https://raw.githubusercontent.com/enen92/screensaver.atv4/master/resources/screenshots/screenshot-01.jpg)

![Screenshot2](https://raw.githubusercontent.com/enen92/screensaver.atv4/master/resources/screenshots/screenshot-02.jpg)

![Screenshot3](https://raw.githubusercontent.com/enen92/screensaver.atv4/master/resources/screenshots/screenshot-03.jpg)

![Screenshot4](https://raw.githubusercontent.com/enen92/screensaver.atv4/master/resources/screenshots/screenshot-04.jpg)

